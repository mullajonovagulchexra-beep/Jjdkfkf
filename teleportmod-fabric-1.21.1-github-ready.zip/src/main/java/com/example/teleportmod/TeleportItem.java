package com.example.teleportmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

public class TeleportItem extends Item {
	private static final double DISTANCE = 32.0;
	private static final int COOLDOWN_TICKS = 20;

	public TeleportItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
		ItemStack stack = player.getStackInHand(hand);

		if (!world.isClient) {
			ServerWorld sw = (ServerWorld) world;
			Vec3d start = player.getEyePos();
			Vec3d look = player.getRotationVec(1.0f);
			Vec3d end = start.add(look.multiply(DISTANCE));

			var hit = world.raycast(new RaycastContext(start, end,
					RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));

			Vec3d target = end;
			if (hit.getType() == HitResult.Type.BLOCK) {
				// отступаем от стены, чтобы не застрять в блоке
				target = hit.getPos().subtract(look.multiply(0.6));
			}
			// глаза -> ноги
			target = target.subtract(0, player.getStandingEyeHeight(), 0);

			// частицы и звук в точке старта
			sw.spawnParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 40, 0.4, 0.8, 0.4, 0.2);
			world.playSound(null, player.getX(), player.getY(), player.getZ(),
					ModSounds.TELEPORT, SoundCategory.PLAYERS, 1.0f, 1.0f);

			player.requestTeleport(target.x, target.y, target.z);
			player.fallDistance = 0;

			// частицы и звук в точке прибытия
			sw.spawnParticles(ParticleTypes.PORTAL, target.x, target.y + 1, target.z, 40, 0.4, 0.8, 0.4, 0.2);
			world.playSound(null, target.x, target.y, target.z,
					ModSounds.TELEPORT, SoundCategory.PLAYERS, 1.0f, 1.0f);

			player.getItemCooldownManager().set(this, COOLDOWN_TICKS);
		}
		return TypedActionResult.success(stack, world.isClient());
	}
}

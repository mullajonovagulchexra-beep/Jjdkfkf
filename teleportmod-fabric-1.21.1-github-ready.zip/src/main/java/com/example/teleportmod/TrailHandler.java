package com.example.teleportmod;

import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Фиолетово-чёрный след за игроком при ходьбе. */
public class TrailHandler {
	private static final DustParticleEffect PURPLE = new DustParticleEffect(new Vector3f(0.6f, 0.1f, 0.95f), 1.3f);
	private static final DustParticleEffect BLACK = new DustParticleEffect(new Vector3f(0.04f, 0.0f, 0.08f), 1.6f);

	private static final Map<UUID, Vec3d> LAST_POS = new HashMap<>();

	public static void tick(MinecraftServer server) {
		for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
			Vec3d pos = player.getPos();
			Vec3d last = LAST_POS.put(player.getUuid(), pos);
			if (last == null || player.isSpectator()) continue;

			if (pos.squaredDistanceTo(last) > 0.0004) {
				ServerWorld world = player.getServerWorld();
				world.spawnParticles(BLACK, pos.x, pos.y + 0.1, pos.z, 4, 0.2, 0.05, 0.2, 0.0);
				world.spawnParticles(PURPLE, pos.x, pos.y + 0.15, pos.z, 3, 0.2, 0.08, 0.2, 0.0);
			}
		}
		LAST_POS.keySet().removeIf(id -> server.getPlayerManager().getPlayer(id) == null);
	}
}

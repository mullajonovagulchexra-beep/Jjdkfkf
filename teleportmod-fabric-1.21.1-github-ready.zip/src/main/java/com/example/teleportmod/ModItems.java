package com.example.teleportmod;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItems {
	public static final Item TELEPORT = new TeleportItem(new Item.Settings().maxCount(1));

	public static final ItemGroup K9IJE_GROUP = FabricItemGroup.builder()
			.icon(() -> new ItemStack(TELEPORT))
			.displayName(Text.translatable("itemGroup.teleportmod"))
			.entries((context, entries) -> entries.add(TELEPORT))
			.build();

	public static void register() {
		Registry.register(Registries.ITEM, Identifier.of(TeleportMod.MOD_ID, "teleport"), TELEPORT);
		Registry.register(Registries.ITEM_GROUP, Identifier.of(TeleportMod.MOD_ID, "main"), K9IJE_GROUP);
	}
}

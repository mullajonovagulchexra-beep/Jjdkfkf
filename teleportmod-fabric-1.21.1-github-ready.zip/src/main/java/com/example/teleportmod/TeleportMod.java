package com.example.teleportmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public class TeleportMod implements ModInitializer {
	public static final String MOD_ID = "teleportmod";

	@Override
	public void onInitialize() {
		ModSounds.register();
		ModItems.register();
		ServerTickEvents.END_SERVER_TICK.register(TrailHandler::tick);
	}
}

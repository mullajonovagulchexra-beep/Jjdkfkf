package com.example.teleportmod;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {
	public static final SoundEvent TELEPORT = SoundEvent.of(Identifier.of(TeleportMod.MOD_ID, "teleport"));

	public static void register() {
		Registry.register(Registries.SOUND_EVENT, TELEPORT.getId(), TELEPORT);
	}
}

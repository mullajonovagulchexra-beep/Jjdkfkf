# Teleport Mod (Fabric 1.21.1)

## Build on GitHub
1. Upload the contents of this folder to the root of a GitHub repository (include the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Fabric mod** and click **Run workflow**. A push to the repository also starts a build.
4. Download the `teleportmod-1.0.0` artifact from the completed workflow run.

Requires Java 21 and targets Minecraft 1.21.1 with Fabric.
